/*
プログラム名 kadai72.c
作成者：佐藤凌輔
作成日：2021/09/09
概要：数字探しトレーニング
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

//マクロ定義
#define MAX_STAGE 5         //出題数
#define MAX_NUM 9           //出題範囲
#define SWAP_COUNT 20       //交換回数

//関数プロトタイプ宣言

void swap(int *point1,int *point2);
void print(int no,const int*p);
void evaluate(time_t s, time_t e);

int main(void)
{
    int question[MAX_NUM-1];        //問題を格納する配列
    int input;                      //入力回答
    int ans;                        //正解
    int no;                         //問題番号
    int *p;                         //問題配列のポインタ番号
    int i;
    time_t start;                   //開始時刻
    time_t end;                     //終了時刻

    //初期処理
    time(&start);                   //開始時間を取得
    srand(time(NULL));              //乱数を初期化する
    printf("[%2d]~[%2d]でかけている数字を入力! \n",1,MAX_NUM);
    //5問出題する
    for(no = 1; no <= MAX_STAGE; no++)
    {
        //問題配列をポインタで操作しながら正解以外の数値を順番に格納する
        ans = rand() % MAX_NUM + 1; //正解(1~9を求める)
        p = question;//問題配列の先頭アドレスを設定
        for(i = 1; i <= MAX_NUM; i++)
        {
            if(i != ans)
            {
                *p = i;
                p++;
            }
        }
        for(i = 0; i < MAX_STAGE; i++)
        {
            int idx1 = rand()% (MAX_NUM-1);     //交換要素の1の添え字を決める
            int idx2 = rand()% (MAX_NUM-1);     //交換要素の2の添え字を決める
            swap(&question[idx1],&question[idx2]);
        }
;
        print(no,question);

        //正解が入力されるまで入力を繰り返す
        scanf("%d",&input);
        while(input != ans)
        {
            printf("もう一度:");
            scanf("%d",&input);
        }
    }
    //後処理
    time(&end);
    evaluate(start,end);       //評価する
	printf("エンターキーを押して終了);
	getche();
	
    return 0;
}

/********************************************
*関数名:swap()
*引　数:交換要素1のアドレス、交換要素２のアドレス
*戻り値:なし
*処　理:二つの参照先の内容を交換する
*********************************************/
void swap(int *point1,int *point2)
{
    int w;
    w = *point1;
    *point1 = *point2;
    *point2 = w;
}
/********************************************
*関数名:print()
*引　数:問題番号(整数型),問題配列のアドレス(ポインタ)
*戻り値:なし
*処　理:問題を表示する
*********************************************/
void print(int no, const int *p)
{
    int i;
    printf("[問題%d]",no);
    for(i = 0; i <MAX_NUM-1; i++)
    {
        printf("|%2d",*(p+i));
    }
    printf("|:");
}
/********************************************
*関数名:evaluate()
*引　数:開始時間(time_t型),終了時間(time_t型)
*戻り値:なし
*処　理:処理時間をもとに評価する
*********************************************/
void evaluate(time_t s, time_t e)
{
    double diff = difftime(e,s);
    printf("[評価(%.0f秒)]",diff);
    if(diff<= 20)
    {
        printf("素早いですね\n");
    }
    else if(diff >= 21 && diff <= 40 )
    {
        printf("まあまあですね");
    }
     else if(diff >= 41 && diff <= 59 )
    {
        printf("遅いですね");
    }
     else 
    {
        printf("遅すぎます");
    }
}

/*
[ 1]~[ 9]でかけている数字を入力! 
[問題1]| 7| 9| 5| 4| 3| 2| 8| 6|:1
[問題2]| 2| 9| 3| 1| 8| 6| 5| 4|:7
[問題3]| 6| 5| 1| 4| 3| 8| 7| 2|:9
[問題4]| 4| 8| 7| 5| 2| 6| 3| 9|:1
[問題5]| 9| 3| 4| 2| 8| 7| 6| 5|:1
[評価(12秒)]素早いですね
*/